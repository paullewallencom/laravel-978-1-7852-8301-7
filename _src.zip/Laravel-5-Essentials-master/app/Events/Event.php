<?php namespace Furbook\Events;

abstract class Event {

	//

}
