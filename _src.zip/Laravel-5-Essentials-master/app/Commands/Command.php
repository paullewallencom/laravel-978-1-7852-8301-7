<?php namespace Furbook\Commands;

abstract class Command {

	//

}
